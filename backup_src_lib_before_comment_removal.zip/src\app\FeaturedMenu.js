"use client";
import { useEffect, useState } from "react";
 
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "../../lib/firebase";

// Swiper imports
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import { Navigation, Pagination } from "swiper/modules";

export default function FeaturedMenu() {
  const [menuItems, setMenuItems] = useState([]);

  useEffect(() => {
    const fetchMenuItems = async () => {
      try {
        const q = query(
          collection(db, "menuItems"),
          where("category", "==", "Special")
        );
        const querySnapshot = await getDocs(q);

        const items = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setMenuItems(items);
      } catch (error) {
        console.error("Error fetching menu items:", error);
      }
    };

    fetchMenuItems();
  }, []);

  // No cart actions in Featured section

  // Reusable card component
  const Card = ({ item }) => (
    <div className="relative bg-black/70 backdrop-blur-md border border-gray-300 rounded-2xl p-6 transform transition-all duration-300 hover:-translate-y-2 hover:shadow-lg hover:shadow-yellow-300/50 group">
      {/* Image */}
      <div className="h-48 rounded-xl mb-6 flex items-center justify-center overflow-hidden">
        {item.photoUrl ? (
          <img
            src={item.photoUrl}
            alt={item.itemName}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <span className="text-gray-400">No Image</span>
        )}
      </div>

      {/* Title */}
      <h4 className="text-2xl font-playfair font-bold mb-2 text-yellow-400">
        {item.itemName}
      </h4>

      {/* Description */}
      <p className="text-gray-300 mb-4">{item.description}</p>

      {/* Price */}
      <div className="flex items-center">
        <span className="text-2xl font-bold text-yellow-400">₹{item.price}</span>
      </div>

      {/* Glow effect */}
      <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-15 bg-yellow-400 blur-xl transition-all"></div>
    </div>
  );

  return (
    <section id="menu" className="py-20 bg-black">
      <div className="container mx-auto px-6">
        {/* Section Title */}
        <div className="text-center mb-16 opacity-0 animate-fadeIn">
          <h3 className="text-5xl font-playfair font-bold text-yellow-400 mb-4">
            Signature Menu
          </h3>
          <p className="text-xl text-gray-300">
            Discover our most celebrated dishes
          </p>
        </div>

        {/* Show Carousel if >3 else Grid */}
        {menuItems.length > 3 ? (
          <Swiper
            modules={[Navigation, Pagination]}
            spaceBetween={20}
            slidesPerView={3}
            navigation
            pagination={{ clickable: true }}
            loop={true}
            autoplay={{ delay: 3000 }}
            className="pb-10"
          >
            {menuItems.map((item) => (
              <SwiperSlide key={item.id}>
                <Card item={item} />
              </SwiperSlide>
            ))}
          </Swiper>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {menuItems.map((item) => (
              <Card key={item.id} item={item} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
