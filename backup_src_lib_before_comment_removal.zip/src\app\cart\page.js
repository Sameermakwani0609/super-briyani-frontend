import Cart from '../Cart';

export default function CartPage() {
  return <Cart />;
}
