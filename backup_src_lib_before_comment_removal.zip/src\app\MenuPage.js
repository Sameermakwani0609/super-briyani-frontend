"use client";

import { useState, useEffect } from "react";
import { GiChickenOven, GiCupcake, GiKnifeFork } from "react-icons/gi";
import { useCart } from "./CartContext";
import { db } from "../../lib/firebase";
import { collection, getDocs } from "firebase/firestore";

export default function MenuPage() {
  const [menuItems, setMenuItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filter, setFilter] = useState("all");
  const { addToCart } = useCart();

  // Map category names to icons
  const categoryIcons = {
    "main course": GiChickenOven,
    starters: GiKnifeFork,
    desserts: GiCupcake,
    all: GiKnifeFork,
  };

  // Fetch menu items from Firestore
  useEffect(() => {
    const fetchMenuItems = async () => {
      const querySnapshot = await getDocs(collection(db, "menuItems"));
      const items = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setMenuItems(items);

      // Extract unique categories from items
      const uniqueCategories = [
        "all",
        ...new Set(items.map((item) => item.category.toLowerCase())),
      ];
      setCategories(uniqueCategories);
    };

    fetchMenuItems();
  }, []);

  const filteredItems =
    filter === "all"
      ? menuItems
      : menuItems.filter(
          (item) => item.category.toLowerCase() === filter.toLowerCase()
        );

  const handleAddToCart = (item) => {
    addToCart(item);
  };

  return (
    <section className="pt-24 pb-16 bg-black text-white">
      <div className="container mx-auto px-4">
        {/* Heading */}
        <h2 className="text-5xl font-bold text-center text-yellow-400 mb-12 drop-shadow-lg">
          Our Menu
        </h2>

        {/* Menu Categories */}
        <div className="flex justify-center mb-8">
          <div className="flex space-x-4 bg-yellow-400/20 p-2 rounded-lg">
            {categories.map((key) => {
              const Icon = categoryIcons[key] || GiKnifeFork; // fallback icon
              return (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors ${
                    filter === key
                      ? "bg-yellow-400 text-black"
                      : "text-yellow-400 hover:bg-yellow-400 hover:text-black"
                  }`}
                >
                  <Icon />
                  <span>{key.charAt(0).toUpperCase() + key.slice(1)}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Menu Items Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-yellow-400/10 border border-yellow-400 rounded-xl p-6 text-center hover:scale-105 hover:bg-yellow-400/20 transition-all"
            >
              {/* Image */}
              <div className="mb-4 h-40 w-full overflow-hidden rounded-lg bg-gray-800 flex items-center justify-center">
                {item.photoUrl ? (
                  <img
                    src={item.photoUrl}
                    alt={item.itemName}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span className="text-gray-400">No Image</span>
                )}
              </div>

              <h3 className="text-2xl font-bold text-yellow-400 mb-2">
                {item.itemName}
              </h3>
              <p className="text-xl mb-4">₹{item.price}</p>
              <button
                onClick={() => handleAddToCart(item)}
                className="bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold hover:bg-yellow-500 transition-colors"
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
