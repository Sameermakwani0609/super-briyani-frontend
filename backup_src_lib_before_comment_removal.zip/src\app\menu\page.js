import MenuPage from '../MenuPage';

export default function Menu() {
  return <MenuPage />;
}

