import AdminDashboard from "../AdminDashboard";

export default function AdminPage() {
  return (
    <div className="w-full h-full">
      <AdminDashboard />
    </div>
  );
}


