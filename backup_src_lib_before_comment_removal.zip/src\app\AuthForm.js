"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { FcGoogle } from "react-icons/fc";
import { signInWithGoogle, onAuthChange, logOut } from "../../lib/authClient";
import { db } from "../../lib/firebase";
import { collection, query, where, getDocs } from "firebase/firestore";
import bcrypt from "bcryptjs";

export default function AuthForm({ onClose }) {
  const router = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.body.style.backgroundColor = "black";
      return () => {
        document.body.style.backgroundColor = "";
      };
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthChange((u) => setUser(u));
    return () => unsub();
  }, []);

  const handleGoogleLogin = async () => {
    setBusy(true);
    try {
      const result = await signInWithGoogle();
      if (result?.user) router.push("/");
    } catch (err) {
      console.error("Google sign-in error:", err);
      alert("Google Sign-In failed.");
    } finally {
      setBusy(false);
    }
  };

  const handleAdminLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) return alert("Enter email & password");

    try {
      const inputEmail = (email || "").trim();
      const q = query(
        collection(db, "admins"),
        where("email", "==", inputEmail)
      );
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        alert("No admin found for this email");
        return;
      }

      const adminDoc = snapshot.docs[0].data();
      let hash = adminDoc.passwordHash || adminDoc.password || null;
      if (!hash || !hash.startsWith("$2")) {
        for (const key of Object.keys(adminDoc)) {
          if (adminDoc[key]?.startsWith("$2")) {
            hash = adminDoc[key];
            break;
          }
        }
      }

      if (!hash) {
        alert("Admin record missing password hash.");
        return;
      }

      const isValid = bcrypt.compareSync(password, hash);
      if (isValid) {
        alert("Login successful!");
        router.push("/admin");
      } else {
        alert("Incorrect password");
      }
    } catch (error) {
      console.error(error);
      alert("Error logging in admin!");
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center px-4 bg-black">
      <div className="w-full max-w-sm bg-yellow-600 rounded-2xl shadow-2xl p-6 flex flex-col items-center">
        {/* Toggle buttons */}
        <div className="flex justify-center mb-6 gap-4 w-full">
          <button
            className={`flex-1 py-2 rounded-lg font-semibold transition-all duration-300 ${
              !isAdmin
                ? "bg-black text-yellow-400 shadow-lg"
                : "bg-yellow-500 text-black hover:bg-yellow-400"
            }`}
            onClick={() => setIsAdmin(false)}
          >
            User
          </button>
          <button
            className={`flex-1 py-2 rounded-lg font-semibold transition-all duration-300 ${
              isAdmin
                ? "bg-black text-yellow-400 shadow-lg"
                : "bg-yellow-500 text-black hover:bg-yellow-400"
            }`}
            onClick={() => setIsAdmin(true)}
          >
            Admin
          </button>
        </div>

        <h2 className="text-3xl font-bold text-black text-center mb-6 transition-colors duration-300">
          {isAdmin ? "Admin Sign In" : "User Login"}
        </h2>

        {!isAdmin ? (
          <>
            {!user ? (
              <button
                type="button"
                disabled={busy}
                className="w-full flex items-center justify-center gap-3 bg-black text-yellow-400 py-3 rounded-lg font-semibold shadow hover:bg-gray-900 transition-all duration-300"
                onClick={handleGoogleLogin}
              >
                <FcGoogle size={24} />
                {busy ? " Signing in..." : "Continue with Google"}
              </button>
            ) : (
              <div className="flex flex-col items-center gap-4">
                <img
                  src={user.photoURL}
                  alt="avatar"
                  className="w-12 h-12 rounded-full"
                />
                <p className="text-black font-semibold">
                  Welcome, {user.displayName}
                </p>
                <button
                  onClick={() => logOut()}
                  className="px-4 py-2 bg-black text-yellow-400 rounded-lg shadow hover:bg-gray-900 transition-all duration-300"
                >
                  Logout
                </button>
              </div>
            )}
          </>
        ) : (
          <form className="space-y-4 w-full" onSubmit={handleAdminLogin}>
            <input
              type="email"
              placeholder="Admin Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-white text-black placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-black transition-all duration-300"
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 rounded-lg bg-white text-black placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-black transition-all duration-300"
            />
            <button
              type="submit"
              className="w-full bg-black text-yellow-400 py-3 rounded-lg font-semibold hover:bg-gray-900 transition-all duration-300"
            >
              Sign In
            </button>
          </form>
        )}
        {/* Back to Home */}
        <button
          type="button"
          onClick={() => {
            if (onClose) onClose();
            router.push("/");
          }}
          className="mt-6 w-full bg-black text-yellow-400 py-2 rounded-lg font-semibold hover:bg-gray-900 transition-all duration-300"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}
